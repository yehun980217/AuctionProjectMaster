package com.red.boot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.red.boot.intercepter.AuthorizationInterceptor;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
    	String[] patterns = new String[]{
                "/member/**", // 패턴 1
                "/question/**",// 패턴 2
                "/trade/**",
                "/qa/**",
                "/item/**",
                "/admin/**"
            };
    	
    	 registry.addInterceptor(new AuthorizationInterceptor())
         .addPathPatterns(patterns);
    }
}
